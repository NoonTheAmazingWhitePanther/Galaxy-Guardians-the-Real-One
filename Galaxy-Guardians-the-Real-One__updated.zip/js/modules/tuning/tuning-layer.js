/**
 * js/modules/tuning/tuning-layer.js
 *
 * Holds references to pinned debug panels and draws them every rAF
 * regardless of whether the debug overlay is toggled on or off.
 *
 * Panels are not duplicated — the same Panel instance is reused.
 * TuningLayer just calls renderPanel on its own list.
 *
 * Usage:
 *   TuningLayer.drawAll(ctx)  — called from mainLoop every frame
 *   TuningLayer.add(panel)    — called by panel.pin()
 *   TuningLayer.remove(panel) — called by panel.unpin()
 */
import { DebugRenderer } from '../rendering/debug-renderer.js';

export const TuningLayer = {
  _panels: [],

  add(panel) {
    if (!this._panels.includes(panel)) {
      this._panels.push(panel);
      console.log(`[TuningLayer] Pinned: ${panel.id}`);
    }
  },

  remove(panel) {
    this._panels = this._panels.filter(p => p !== panel);
    console.log(`[TuningLayer] Unpinned: ${panel.id}`);
  },

  // Called every rAF from main.js inside shouldRender block.
  // Only draws when debug is OFF — when debug is ON, DebugRouter.drawAll
  // already draws pinned panels as part of its normal panel list.
  drawAll(ctx) {
    if (this._panels.length === 0) return;
    if (window._DebugRouter?.masterEnabled) return;

    console.log('[TuningLayer] drawing', this._panels.length, 'panels');
    for (const panel of this._panels) {
      DebugRenderer.renderPanel(ctx, panel, panel._cachedData ?? {});
    }
  },

  get count() {
    return this._panels.length;
  }
};

// Expose globally so Panel.pin() can reach it without circular imports
window._TuningLayer = TuningLayer;

// Drain any panels that were pinned before TuningLayer was ready
if (window._tuningPinQueue?.length) {
  for (const panel of window._tuningPinQueue) TuningLayer.add(panel);
  window._tuningPinQueue = [];
}

export default TuningLayer;
