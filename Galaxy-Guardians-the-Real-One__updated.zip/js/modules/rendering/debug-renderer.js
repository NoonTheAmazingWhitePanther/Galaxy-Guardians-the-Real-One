/**
 * js/modules/rendering/debug-renderer.js
 *
 * Offscreen canvas caching — each panel renders to an OffscreenCanvas
 * (or regular canvas for compatibility) and blits with a single drawImage.
 *
 * Two canvases per panel:
 *   panel._chromeCanvas → minimized state composite
 *   panel._dataCanvas   → expanded state composite
 *
 * Dirty flags:
 *   panel._chromeDirty  → layout/chrome changed (minimize, pin, resize)
 *   panel._dataDirty    → data values changed
 * Either flag triggers a full redraw of the relevant offscreen.
 * Every rAF: one drawImage per panel onto the main canvas.
 */
import { DEBUG_STATE } from '../debug/debug-state.js';
import { ControlRenderer } from '../debug/controls.js';
import { PanelMasterSlider } from '../debug/panel-master.js';
import { MasterSliderRenderer } from '../debug/master-slider-renderer.js';

function makeCanvas(w, h) {
  // Use OffscreenCanvas where available, fall back to regular canvas
  if (typeof OffscreenCanvas !== 'undefined') {
    return new OffscreenCanvas(w, h);
  }
  const c = document.createElement('canvas');
  c.width  = w;
  c.height = h;
  return c;
}

export const DebugRenderer = {

  drawRoundedRect(ctx, x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h - r);
    ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h + r);
    ctx.lineTo(x + r, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - r);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.closePath();
  },

  renderPanel(ctx, panel, data) {
    if (!panel.visible) return;

    const s          = DEBUG_STATE.style;
    const sc         = DEBUG_STATE.scale;
    const layout     = panel.computeLayout(data);
    const pw         = Math.floor(layout.w);
    const ph         = Math.floor(layout.h);
    const { minimized } = layout;

    // ── Chrome layer — cached offscreen (background, border, amber) ───────
    const chromeCanvas = panel._chromeCanvas;
    const chromeDirty  = panel._chromeDirty
      || !chromeCanvas
      || chromeCanvas.width  !== pw
      || chromeCanvas.height !== ph;

    if (chromeDirty) {
      const c = makeCanvas(pw, ph);
      panel._chromeCanvas = c;
      this._drawChrome(c, panel, pw, ph, sc, s, minimized);
      panel._chromeDirty = false;
    }

    // Blit chrome
    ctx.drawImage(panel._chromeCanvas, panel.x, panel.y);

    if (minimized) {
      // Minimized — PanelMasterSlider draws text/knob on main ctx
      PanelMasterSlider.render(ctx, panel, panel.x, panel.y, pw, ph, minimized);
      return;
    }

    // ── Data layer — always redrawn live, no cache ────────────────────────
    // Values come from GovernorRegistry live reads inside _resolveValue.
    // Caching would show stale numbers. Just draw every rendered frame.
    ctx.save();
    ctx.translate(panel.x, panel.y);
    this._drawData(ctx, panel, data, layout, pw, ph, sc, s);
    ctx.restore();

    // PanelMasterSlider — interactive, draws on main canvas
    PanelMasterSlider.render(ctx, panel, panel.x, panel.y, pw, ph, minimized);

    panel.w = pw;
    panel.h = ph;
  },

  // Chrome = background, border, amber border, buttons — cached
  _drawChrome(canvas, panel, pw, ph, sc, s, minimized) {
    const ctx    = canvas.getContext('2d');
    const radius = s.radius * sc;

    ctx.clearRect(0, 0, pw, ph);

    // Background
    // TODO: Support custom panel backgrounds from panel.config.background.
    // Options: solid colour string, gradient descriptor, image URL.
    // Null (default) falls through to theme background.
    const bgFill = panel.config?.background ?? s.bg;
    ctx.save();
    ctx.shadowColor   = s.shadowColor;
    ctx.shadowBlur    = s.shadowBlur * sc;
    ctx.shadowOffsetY = s.shadowOffsetY * sc;
    ctx.fillStyle     = bgFill;
    ctx.beginPath();
    ctx.roundRect(0, 0, pw, ph, radius);
    ctx.fill();
    ctx.restore();

    // Border
    ctx.strokeStyle = s.border;
    ctx.lineWidth   = 1;
    ctx.beginPath();
    ctx.roundRect(0.5, 0.5, pw - 1, ph - 1, radius);
    ctx.stroke();

    // Amber border for pinned panels
    if (panel.pinned) {
      ctx.strokeStyle = 'rgba(255,200,80,0.33)';
      ctx.lineWidth   = 2;
      ctx.beginPath();
      ctx.roundRect(1, 1, pw - 2, ph - 2, 6);
      ctx.stroke();
    }

    // Title bar — drag handle highlight + buttons (expanded only)
    if (!minimized) {
      ctx.fillStyle = 'rgba(255,255,255,0.04)';
      ctx.beginPath();
      ctx.roundRect(1, 1, pw - 2, 28, [radius, radius, 0, 0]);
      ctx.fill();
      // Drag handle dots — three dots centred, subtle
      ctx.fillStyle = 'rgba(255,255,255,0.18)';
      for (let i = -1; i <= 1; i++) {
        ctx.beginPath();
        ctx.arc(pw / 2 + i * 5, 14, 1.5, 0, Math.PI * 2);
        ctx.fill();
      }

    }
    // Resize grip ⊿ bottom-right corner — always shown
    const gripSize = 12;
    const gripX    = pw - gripSize - 2;
    const gripY    = ph - gripSize - 2;
    ctx.fillStyle  = 'rgba(240,245,255,0.25)';
    ctx.font       = `${gripSize}px ${s.font}`;
    ctx.textAlign  = 'right';
    ctx.textBaseline = 'bottom';
    ctx.fillText('⊿', pw - 2, ph - 2);
  },
  _drawData(ctx, panel, data, layout, pw, ph, sc, s) {
    const { lines, controls } = layout;
    const fontSize   = s.fontSize * sc;
    const padX       = s.padX * sc;
    const padY       = s.padY * sc;
    const lineHeight = s.lineHeight * sc;
    const scrollOff  = layout.scrollOffset ?? 0;

    ctx.textBaseline = 'middle';

    ctx.save();
    ctx.beginPath();
    ctx.rect(padX, padY, pw - padX * 2, ph - padY);
    ctx.clip();
    ctx.translate(0, -scrollOff);

    let ly = padY + lineHeight / 2;
    for (const ln of lines) {
      const fs = ln.small ? fontSize - 1 : fontSize;
      if (ln.isSectionHeader) {
        const arrow = ln.collapsed ? '▶' : '▼';
        ctx.font      = `bold ${fs}px ${s.font}`;
        ctx.fillStyle = 'rgba(130,210,255,0.7)';
        ctx.textAlign = 'left';
        ctx.fillText(`${arrow} ${ln.label}`, padX, ly);
        if (ln.collapsed && ln.total !== null && ln.total !== undefined) {
          ctx.textAlign = 'right';
          ctx.fillStyle = 'rgba(240,245,255,0.5)';
          ctx.fillText(String(ln.total), pw - padX, ly);
        }
      } else {
        ctx.font      = `${ln.bold ? 'bold ' : ''}${fs}px ${s.font}`;
        ctx.fillStyle = ln.color || s.textDim;
        ctx.textAlign = 'left';
        ctx.fillText(ln.label || '', padX, ly);
        ctx.textAlign = 'right';
        ctx.fillText(ln.value || '', pw - padX, ly);
      }
      ly += lineHeight;
    }

    for (const ctrl of controls) {
      const { bounds, state } = ctrl;
      ControlRenderer.render(ctx, ctrl, bounds.x, bounds.y, bounds.w, bounds.h, state);
    }

    ctx.restore();

    // 2px scroll indicator — clamped so it never exits panel bounds
    if (layout.scrollable && layout.totalContentH > 0) {
      const trackH   = ph - padY * 2;
      const progress = Math.min(1, scrollOff / Math.max(1, layout.totalContentH - ph));
      const dotH     = Math.max(6, trackH * (ph / layout.totalContentH));
      const dotY     = padY + progress * (trackH - dotH);  // clamp within track

      ctx.fillStyle  = 'rgba(130,210,255,0.35)';
      ctx.beginPath();
      ctx.roundRect(2, padY, 2, trackH, 1);
      ctx.fill();
      ctx.fillStyle  = 'rgba(130,210,255,0.8)';
      ctx.beginPath();
      ctx.roundRect(2, dotY, 2, dotH, 1);
      ctx.fill();
    }

    // ── Icons drawn LAST — always on top of all text ─────────────────────
    const minBtnSize = 16;
    const minBtnX    = pw - minBtnSize - 6;
    const minBtnY    = 6;
    const pinBtnX    = minBtnX - minBtnSize - 4;

    // Pin button
    if (window._DebugRouter?.masterEnabled) {
      ctx.fillStyle    = panel.pinned ? 'rgba(255,200,80,1)' : 'rgba(240,245,255,0.45)';
      ctx.font         = `10px ${s.font}`;
      ctx.textAlign    = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('📌', pinBtnX + minBtnSize / 2, minBtnY + minBtnSize / 2);
    }

    // Minimize button — opaque bg so text doesn't bleed through
    ctx.fillStyle = 'rgba(20,24,36,0.85)';
    ctx.beginPath();
    ctx.roundRect(minBtnX, minBtnY, minBtnSize, minBtnSize, 3);
    ctx.fill();
    ctx.fillStyle    = 'rgba(240,245,255,0.85)';
    ctx.font         = `10px ${s.font}`;
    ctx.textAlign    = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('▼', minBtnX + minBtnSize / 2, minBtnY + minBtnSize / 2);
  },

  renderMasterSlider(ctx, panels) {
    MasterSliderRenderer.render(ctx, panels);
  }
};
