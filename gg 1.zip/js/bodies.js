import { PARTICLE_R, SPRING_K, BREAK_MULT, PALS, RING_MIN_RADIUS, RING_PARTICLES, GRAV_CONST, SUN, sunGravMult } from './constants.js';
import { rnd, lerp } from './utils.js';
import { cam } from './camera.js';

export let bodies = [];
export let loose = [];
export let flashes = [];

// ---- Helper to update particle count display ----
export let updateCountCallback = null;
export function setUpdateCountCallback(fn) { updateCountCallback = fn; }

function updateCount() { if(updateCountCallback) updateCountCallback(); }

// ---- Particle and spring creation ----
export function makeParticle(x, y, mass, pal, isCore) {
  return { x, y, vx:0, vy:0, fx:0, fy:0, mass: mass||1, pal, isCore:!!isCore, body:null, dead:false, heat:0 };
}

export function makeSpring(a, b, restLen, stiff, breakAt) {
  return { a, b, restLen, stiff: stiff||SPRING_K, breakAt: breakAt||(restLen*BREAK_MULT), broken:false };
}

export function makeBody(cx, cy, radius, pal) {
  const particles = [], springs = [], grid = {};
  const spacing = PARTICLE_R * 1.82;
  const rows = Math.ceil(radius/spacing)*2 + 1, cols = rows;
  const ox = cx - (cols-1)*spacing*0.5, oy = cy - (rows-1)*spacing*0.5;
  
  for(let row=0; row<rows; row++) {
    for(let col=0; col<cols; col++) {
      const px = ox + col*spacing + (row%2)*0.5*spacing, py = oy + row*spacing;
      const dx = px-cx, dy = py-cy;
      if(Math.hypot(dx,dy) > radius + spacing*0.3) continue;
      const p = makeParticle(px, py, 1, pal, Math.hypot(dx,dy) < radius*0.3);
      grid[`${col},${row}`] = particles.length;
      particles.push(p);
    }
  }
  const dirs = [[1,0],[0,1],[1,1],[-1,1],[2,0],[0,2]], seen = new Set();
  for(let row=0; row<rows; row++) {
    for(let col=0; col<cols; col++) {
      const ai = grid[`${col},${row}`];
      if(ai === undefined) continue;
      for(const [dc, dr] of dirs) {
        const bi = grid[`${col+dc},${row+dr}`];
        if(bi === undefined) continue;
        const key = ai<bi ? `${ai}-${bi}` : `${bi}-${ai}`;
        if(seen.has(key)) continue;
        seen.add(key);
        const pa = particles[ai], pb = particles[bi];
        const len = Math.hypot(pb.x-pa.x, pb.y-pa.y);
        const isDirect = len < spacing*1.2;
        springs.push(makeSpring(ai, bi, len,
          isDirect ? SPRING_K : SPRING_K*0.6,
          isDirect ? len*BREAK_MULT : len*BREAK_MULT*0.8));
      }
    }
  }
  for(const p of particles) {
    const d = Math.hypot(p.x-cx, p.y-cy)/radius;
    p.mass = lerp(2.0, 0.6, d);
  }
  const body = { particles, springs, pal, cx, cy, mass:0, radius, dead:false, gravMult: sunGravMult };
  let tm = 0;
  for(const p of particles) { p.body = body; tm += p.mass; }
  body.mass = tm;
  return body;
}

// ---- Flash effects ----
export function addFlash(x, y, r, gc) {
  flashes.push({x,y, r: r*0.05, maxR: r*3,  gc, life:0.55, speed:.14, kind:'ring'});
  flashes.push({x,y, r: r*0.1,  maxR: r*2,  gc, life:0.45, speed:.12, kind:'fill'});
  flashes.push({x,y, r: 0,      maxR: r*0.8, gc, life:0.60, speed:.10, kind:'core'});
}

export function addNova(x, y, r, gc) {
  flashes.push({x,y, r: r*0.9,  maxR: r*1.6, gc, life:0.9, speed:.18, kind:'white'});
  flashes.push({x,y, r: r*0.04, maxR: r*3.5, gc, life:0.70, speed:.11, kind:'ring'});
  flashes.push({x,y, r: r*0.08, maxR: r*2.2, gc, life:0.55, speed:.10, kind:'fill'});
  flashes.push({x,y, r: r*0.15, maxR: r*1.3, gc, life:0.65, speed:.09, kind:'fill'});
  flashes.push({x,y, r: 0,      maxR: r*0.9, gc, life:0.75, speed:.08, kind:'core'});
}

// ---- Spawn planet ----
export function spawnPlanet(x, y, size, GRAV_CONST_local, SUN_local, sunGravMult_local) {
  if(bodies.length >= 8) return;
  const radius = clamp(size*8, 16, 110);
  const pal = PALS[Math.floor(rnd()*PALS.length)];
  const body = makeBody(x, y, radius, pal);
  const nP = body.particles.length;
  body.gravMult = sunGravMult_local;
  // circular orbital velocity
  const dx = x - SUN_local.x, dy = y - SUN_local.y, dist = Math.hypot(dx,dy)||1;
  const v = Math.sqrt(GRAV_CONST_local * SUN_local.mass * sunGravMult_local / Math.max(nP,1) / dist);
  const vx = -dy/dist * v, vy = dx/dist * v;
  for(const p of body.particles) { p.vx = vx; p.vy = vy; }
  bodies.push(body);
  addFlash(x, y, radius*2, pal.gc);
  updateCount();
}

// ---- Ring debris after planet death ----
export function spawnRing(body, GRAV_CONST_local, SUN_local) {
  const rx = body.cx, ry = body.cy;
  const dist = Math.hypot(rx - SUN_local.x, ry - SUN_local.y) || 1;
  const ringW = body.radius * 0.6;
  addFlash(rx, ry, body.radius*4, body.pal.gc);
  addNova(rx, ry, body.radius*3, body.pal.gc);
  const gmLocal = GRAV_CONST_local * SUN_local.mass * (body.gravMult||1);
  for(let i=0; i<RING_PARTICLES; i++) {
    const angle = (Math.PI*2/RING_PARTICLES)*i + rndR(-0.05, 0.05);
    const r = dist + rndR(-ringW, ringW);
    const px = SUN_local.x + Math.cos(angle)*r;
    const py = SUN_local.y + Math.sin(angle)*r;
    const vLocal = Math.sqrt(gmLocal / Math.max(r,1));
    const scatter = rndR(0.96, 1.04);
    const vx = -Math.sin(angle) * vLocal * scatter;
    const vy =  Math.cos(angle) * vLocal * scatter;
    loose.push({
      x:px, y:py, vx, vy,
      mass: rndR(0.4, 1.2),
      pal: body.pal,
      heat: rndR(0.3, 0.8),
      life: rndR(0.7, 1.0),
      decay: rndR(0.0005, 0.002),
      isRing: true,
    });
  }
}

// ---- Clean up dead bodies and convert to loose particles ----
export function splitDeadParticles(body, GRAV_CONST_local, SUN_local, RING_MIN_RADIUS_local) {
  const {particles:ps, springs:ss} = body;
  const n = ps.length;
  if(!n) return;
  const adj = Array.from({length:n}, () => []);
  for(const sp of ss) {
    if(!sp.broken && !ps[sp.a].dead && !ps[sp.b].dead) {
      adj[sp.a].push(sp.b);
      adj[sp.b].push(sp.a);
    }
  }
  const vis = new Uint8Array(n);
  let seed = -1;
  for(let i=0;i<n;i++) { if(!ps[i].dead) { seed = i; break; } }
  if(seed === -1) return;
  const q = [seed];
  vis[seed] = 1;
  while(q.length) {
    const c = q.shift();
    for(const nb of adj[c]) if(!vis[nb]) { vis[nb]=1; q.push(nb); }
  }
  let alive = 0;
  for(let i=0;i<n;i++) {
    const p = ps[i];
    if(p.dead) continue;
    if(!vis[i]) {
      loose.push({x:p.x, y:p.y, vx:p.vx, vy:p.vy, mass:p.mass, pal:p.pal, heat:p.heat, life:1, decay:rndR(.004,.008)});
      p.dead = true;
    } else {
      alive++;
    }
  }
  if(alive < Math.max(3, n*0.08)) {
    for(const p of ps) if(!p.dead)
      loose.push({x:p.x, y:p.y, vx:p.vx, vy:p.vy, mass:p.mass, pal:p.pal, heat:1, life:1, decay:rndR(.005,.01)});
    if(body.radius >= RING_MIN_RADIUS_local) spawnRing(body, GRAV_CONST_local, SUN_local);
    body.dead = true;
  }
}