// Galaxy Guardians – Constants (immutable and mutable globals)

// ---------- Immutable ----------
export const BREAK_MULT  = 2.8;
export const PHYS_SCALE  = 60;

export const SUN = {
  x: 0, y: 0,
  radius: 180,
  burnRadius: 220,
  mass: 182784,
  coronaTime: 0,
};

export const PALS = [
  {hi:'#ffeeaa',mid:'#ff8800',lo:'#5a1800',gc:'255,140,50'},
  {hi:'#cceeff',mid:'#0088ff',lo:'#001a44',gc:'60,180,255'},
  {hi:'#eeccff',mid:'#aa00ff',lo:'#1a0033',gc:'160,60,255'},
  {hi:'#aaffcc',mid:'#00cc66',lo:'#003322',gc:'40,200,120'},
  {hi:'#ffccee',mid:'#ff0077',lo:'#330011',gc:'255,60,140'},
  {hi:'#ffffaa',mid:'#ddcc00',lo:'#332200',gc:'220,200,60'},
];

export const AST_PALETTE = [
  {fill:'#9c8e7a', outline:'#6b5e50', dot:'#c4b49a'},
  {fill:'#7a8490', outline:'#505860', dot:'#a8b4bc'},
  {fill:'#9a8840', outline:'#605420', dot:'#d4c870'},
  {fill:'#6a8890', outline:'#384858', dot:'#90b8c0'},
];

export const AST_SPAWN_INTERVAL = 600;
export const AST_MAX            = 6;

export const RING_MIN_RADIUS = 40;
export const RING_PARTICLES  = 80;

export const TRAIL_STEPS = 5;
export const TRAIL_ALPHAS = [1.0, 0.52, 0.24, 0.09, 0.02];

// ---------- Mutable physics parameters ----------
export let GRAV_CONST    = 120;
export let SPRING_K      = 0.40;
export let DAMPING       = 1.0;
export let SUBSTEPS      = 8;
export let PARTICLE_R    = 2.8;
export let COLLISION_R   = PARTICLE_R * 1.15;
export let LOOSE_HIT_R   = PARTICLE_R * 3.5;
export let sunGravMult   = 1.0;

export function updateCollisionRadius() {
  COLLISION_R = PARTICLE_R * 1.15;
  LOOSE_HIT_R = PARTICLE_R * 3.5;
}

export function resetPhysicsParams() {
  GRAV_CONST = 120;
  SPRING_K = 0.40;
  DAMPING = 1.0;
  SUBSTEPS = 8;
  PARTICLE_R = 2.8;
  updateCollisionRadius();
  // sunGravMult is not reset (handled by UI slider)
}