import { SUN, GRAV_CONST, SPRING_K, DAMPING, SUBSTEPS, PARTICLE_R, COLLISION_R, LOOSE_HIT_R, sunGravMult, updateCollisionRadius, resetPhysicsParams, PHYS_SCALE, RING_MIN_RADIUS } from './constants.js';
import { initCamera, cam, tickCam, applyCam, frameBodies, screenToWorld } from './camera.js';
import { bodies, loose, flashes, spawnPlanet, setUpdateCountCallback, splitDeadParticles, addFlash, addNova } from './bodies.js';
import { tickAsteroids, asteroids, drawAsteroids } from './asteroids.js';
import { initRendering, drawStars, drawNebula, drawSun, drawLoose, drawBody, drawFlashes, drawCharge, drawTrail, renderPlanetsToBuffer, advanceTrailBuffer, drawFPS, resizeTrailBuffers } from './rendering.js';
import { drawOrbitPreviewFull } from './preview.js';
import { initUI } from './ui.js';
import { PI2, clamp, lerp, rnd, rndR } from './utils.js';
// Global variables for physics state
let lastT = 0;
let fpsSamples = [], fpsDisplay = 0;
let W, H, ctx, canvas;

// Make constants available globally for UI and preview
window.GRAV_CONST = GRAV_CONST;
window.SPRING_K = SPRING_K;
window.DAMPING = DAMPING;
window.SUBSTEPS = SUBSTEPS;
window.PARTICLE_R = PARTICLE_R;
window.COLLISION_R = COLLISION_R;
window.LOOSE_HIT_R = LOOSE_HIT_R;
window.sunGravMult = sunGravMult;
window.SUN = SUN;
window.updateCollisionRadius = updateCollisionRadius;

// --- Physics functions that need global access ---
function integrateParticle(p, dt) {
  if(p.dead) return;
  p.vx = (p.vx + p.fx/p.mass * dt) * DAMPING;
  p.vy = (p.vy + p.fy/p.mass * dt) * DAMPING;
  p.x += p.vx * dt;
  p.y += p.vy * dt;
  p.fx = 0; p.fy = 0;
}

function solveSprings(body, dt) {
  const {particles:ps, springs:ss} = body;
  for(const sp of ss) {
    if(sp.broken) continue;
    const pa = ps[sp.a], pb = ps[sp.b];
    if(pa.dead || pb.dead) { sp.broken = true; continue; }
    const dx = pb.x - pa.x, dy = pb.y - pa.y;
    const len = Math.hypot(dx,dy) || 0.001;
    if(len > sp.breakAt) { sp.broken = true; continue; }
    const f = sp.stiff * (len - sp.restLen), nx = dx/len, ny = dy/len;
    const tm = pa.mass + pb.mass;
    pa.vx += nx * f * (pb.mass/tm) * dt;
    pa.vy += ny * f * (pb.mass/tm) * dt;
    pb.vx -= nx * f * (pa.mass/tm) * dt;
    pb.vy -= ny * f * (pa.mass/tm) * dt;
  }
}

function applyGravity(p, nParticles) {
  const gm = (p.body && p.body.gravMult != null) ? p.body.gravMult : window.sunGravMult;
  const sdx = SUN.x - p.x, sdy = SUN.y - p.y;
  const sd2 = sdx*sdx + sdy*sdy, sd = Math.sqrt(sd2)+0.1;
  const sf = (GRAV_CONST * SUN.mass * gm / (sd2+500)) / nParticles;
  p.fx += sdx/sd * sf * p.mass;
  p.fy += sdy/sd * sf * p.mass;
  for(const b of bodies) {
    if(p.body === b) continue;
    const dx = b.cx - p.x, dy = b.cy - p.y;
    const d2 = dx*dx+dy*dy, d = Math.sqrt(d2)+0.1;
    const f = (GRAV_CONST * b.mass / (d2+300)) / nParticles;
    p.fx += dx/d * f * p.mass;
    p.fy += dy/d * f * p.mass;
  }
}

function interBodyCollisions() {
  for(let bi=0; bi<bodies.length; bi++) {
    for(let bj=bi+1; bj<bodies.length; bj++) {
      const A = bodies[bi], B = bodies[bj];
      const cdx = A.cx - B.cx, cdy = A.cy - B.cy;
      const cd2 = cdx*cdx + cdy*cdy;
      const thresh = A.radius + B.radius + COLLISION_R*4;
      if(cd2 > thresh*thresh) continue;
      const cellSize = COLLISION_R*2;
      const grid = new Map();
      const addCell = (p,tag) => {
        const cx = Math.floor(p.x/cellSize), cy = Math.floor(p.y/cellSize);
        const key = cx+','+cy;
        if(!grid.has(key)) grid.set(key,[]);
        grid.get(key).push({p,tag});
      };
      for(const p of A.particles) if(!p.dead) addCell(p,0);
      for(const p of B.particles) if(!p.dead) addCell(p,1);
      for(const cell of grid.values()) {
        let hasA=false, hasB=false;
        for(const e of cell) { if(e.tag===0) hasA=true; else hasB=true; if(hasA&&hasB) break; }
        if(!hasA||!hasB) continue;
        for(const ea of cell) {
          if(ea.tag!==0) continue;
          const pa = ea.p;
          for(const eb of cell) {
            if(eb.tag!==1) continue;
            const pb = eb.p;
            const dx = pb.x - pa.x, dy = pb.y - pa.y;
            const d2 = dx*dx+dy*dy;
            if(d2 >= COLLISION_R*COLLISION_R) continue;
            const d = Math.sqrt(d2)||0.001, nx=dx/d, ny=dy/d;
            const ov = COLLISION_R - d, ma=pa.mass, mb=pb.mass, mt=ma+mb;
            pa.x -= nx*ov*(mb/mt); pa.y -= ny*ov*(mb/mt);
            pb.x += nx*ov*(ma/mt); pb.y += ny*ov*(ma/mt);
            const vn = (pa.vx-pb.vx)*nx + (pa.vy-pb.vy)*ny;
            if(vn < 0) {
              const j = -(1+0.45)*vn / (1/ma + 1/mb);
              pa.vx += j*nx/ma; pa.vy += j*ny/ma;
              pb.vx -= j*nx/mb; pb.vy -= j*ny/mb;
              pa.heat = clamp(pa.heat + Math.abs(vn)*0.15, 0, 1);
              pb.heat = clamp(pb.heat + Math.abs(vn)*0.15, 0, 1);
            }
          }
        }
      }
    }
  }
}

function updateCOM(body) {
  let sx=0,sy=0,sm=0;
  for(const p of body.particles) {
    if(p.dead) continue;
    sx += p.x*p.mass; sy += p.y*p.mass; sm += p.mass;
  }
  if(sm>0) { body.cx = sx/sm; body.cy = sy/sm; body.mass = sm; }
}

function looseVsPlanets() {
  const MAX_LOOSE_CHECKS = 200;
  const step = loose.length > MAX_LOOSE_CHECKS ? Math.floor(loose.length/MAX_LOOSE_CHECKS) : 1;
  for(let li=loose.length-1; li>=0; li-=step) {
    const lp = loose[li];
    if(lp.life <= 0) continue;
    for(const body of bodies) {
      const bdx = body.cx - lp.x, bdy = body.cy - lp.y;
      const bd2 = bdx*bdx + bdy*bdy;
      const thresh = body.radius + LOOSE_HIT_R*2;
      if(bd2 > thresh*thresh) continue;
      let nearP = null, nearD2 = Infinity;
      for(const bp of body.particles) {
        if(bp.dead) continue;
         dx = bp.x - lp.x, dy = bp.y - lp.y;
        const d2 = dx*dx+dy*dy;
        if(d2 < nearD2) { nearD2 = d2; nearP = bp; }
      }
      const nearD = Math.sqrt(nearD2);
      if(!nearP || nearD > LOOSE_HIT_R) continue;
       dx = nearP.x - lp.x, dy = nearP.y - lp.y, d = Math.hypot(dx,dy)||0.001;
      const nx = dx/d, ny = dy/d;
      const vn = (lp.vx - nearP.vx)*nx + (lp.vy - nearP.vy)*ny;
      if(Math.abs(vn) < 0.8) {
        nearP.vx += lp.vx * lp.mass / nearP.mass * 0.3;
        nearP.vy += lp.vy * lp.mass / nearP.mass * 0.3;
        nearP.heat = Math.min(1, nearP.heat + 0.25);
        lp.life = 0;
      } else if(vn > 0) {
        lp.x -= nx*(LOOSE_HIT_R - nearD)*0.9;
        lp.y -= ny*(LOOSE_HIT_R - nearD)*0.9;
        const ma = lp.mass, mb = nearP.mass;
        const j = -(1+0.55)*vn / (1/ma + 1/mb);
        lp.vx -= j*nx/ma; lp.vy -= j*ny/ma;
        nearP.vx += j*nx/mb; nearP.vy += j*ny/mb;
        const h = clamp(Math.abs(vn)*0.12, 0, 1);
        lp.heat = Math.min(1, lp.heat + h);
        nearP.heat = Math.min(1, nearP.heat + h*1.5);
        if(Math.abs(vn) > 2) {
          for(let k=0;k<3;k++) {
            const a = Math.atan2(-ny, -nx) + (rnd()-0.5)*1.2;
            const s = rnd() * Math.abs(vn)*0.4 + 0.5;
            loose.push({
              x: lp.x, y: lp.y,
              vx: Math.cos(a)*s, vy: Math.sin(a)*s,
              mass: lp.mass*0.15, pal: lp.pal, heat:0.8, life:0.6, decay: rndR(0.02,0.04)
            });
          }
        }
      }
      break;
    }
  }
}

function tickLoose(dt) {
  if(loose.length > 400) loose.splice(0, loose.length-400);
  loose = loose.filter(p => p.life > 0);
  for(const p of loose) {
    const sdx = SUN.x - p.x, sdy = SUN.y - p.y;
    const sd2 = sdx*sdx+sdy*sdy, sd = Math.sqrt(sd2)+0.1;
    if(sd < SUN.burnRadius) { p.life = 0; continue; }
    const sf = GRAV_CONST * SUN.mass * window.sunGravMult / (sd2+500) * 0.04;
    p.vx += sdx/sd * sf * dt;
    p.vy += sdy/sd * sf * dt;
    for(const b of bodies) {
      const dx = b.cx - p.x, dy = b.cy - p.y, d2 = dx*dx+dy*dy, d = Math.sqrt(d2)+0.1;
      const f = GRAV_CONST * b.mass * (p.isRing?0.01:0.12) / (d2+150);
      p.vx += dx/d * f * dt;
      p.vy += dy/d * f * dt;
    }
    p.vx *= 0.997; p.vy *= 0.997;
    p.x += p.vx * dt; p.y += p.vy * dt;
    p.heat = sd < SUN.burnRadius*3 ? Math.min(1, p.heat+0.02*dt) : Math.max(0, p.heat-0.005*dt);
    p.life -= p.decay * dt;
  }
}

function tickBodies(scaledDt) {
  const dt = scaledDt / SUBSTEPS;
  const nAlives = bodies.map(b => { let n=0; for(const p of b.particles) if(!p.dead) n++; return n||1; });
  for(let sub=0; sub<SUBSTEPS; sub++) {
    for(let bi=0; bi<bodies.length; bi++) {
      const body = bodies[bi], na = nAlives[bi];
      for(const p of body.particles) if(!p.dead) applyGravity(p, na);
    }
    for(const body of bodies) for(const p of body.particles) integrateParticle(p, dt);
    for(const body of bodies) solveSprings(body, dt);
    for(const body of bodies) for(const p of body.particles) {
      if(p.dead) continue;
      const dx = SUN.x - p.x, dy = SUN.y - p.y, sd2 = dx*dx+dy*dy;
      if(sd2 < SUN.burnRadius*SUN.burnRadius) p.dead = true;
      else if(sd2 < SUN.burnRadius*SUN.burnRadius*6.25) p.heat = Math.min(1, p.heat+0.04);
    }
    if(sub === SUBSTEPS-1) interBodyCollisions();
  }
  for(const body of bodies) updateCOM(body);
  for(const body of bodies)
    splitDeadParticles(body, GRAV_CONST, SUN, RING_MIN_RADIUS);bodies = bodies.filter(b => !b.dead);
  looseVsPlanets();
}

function updateFPS(rawDt) {
  if(rawDt>0) { fpsSamples.push(1/rawDt); if(fpsSamples.length>30) fpsSamples.shift(); }
  if(fpsSamples.length>0) fpsDisplay = Math.round(fpsSamples.reduce((a,b)=>a+b)/fpsSamples.length);
}

function resize() {
  W = canvas.width = window.innerWidth;
  H = canvas.height = window.innerHeight;
  initRendering(W, H, ctx);
  resizeTrailBuffers();
}

function mainLoop(t) {
  requestAnimationFrame(mainLoop);
  const rawDt = Math.min((t - lastT)/1000, 0.05);
  lastT = t;
  updateFPS(rawDt);
  
  tickCam();
  window.updateSpeedBar?.();
  window.updateZoomBar?.();
  
  ctx.fillStyle = 'rgba(4,4,12,0.28)';
  ctx.fillRect(0,0,W,H);
  drawNebula(t);
  drawStars(t);
  
  ctx.save();
  applyCam();
  
  const physSpeed = window.physSpeed || 1;
  const paused = window.paused || false;
  if(!paused && physSpeed > 0 && rawDt > 0) {
    const MAX_SAFE_SD = rawDt * 3.0 * PHYS_SCALE;
    const totalSd = rawDt * physSpeed * PHYS_SCALE;
    const numTicks = Math.ceil(totalSd / MAX_SAFE_SD);
    const sdPerTick = totalSd / numTicks;
    for(let tick=0; tick<numTicks; tick++) {
      tickBodies(sdPerTick);
      tickLoose(sdPerTick);
    }
    tickAsteroids(rawDt * physSpeed * PHYS_SCALE, physSpeed);
  }
  
  drawFlashes();
  drawSun(t, SUN);
  drawLoose();
  drawAsteroids(ctx);
  
  const { getTx, getTy, getHolding, getHoldT, getSliderValue } = window.uiGetters;
  drawOrbitPreviewFull(ctx, t, getTx(), getTy(), getHolding(), getHoldT(), getSliderValue(), physSpeed);
  ctx.restore();
  
  renderPlanetsToBuffer();
  drawTrail();
  advanceTrailBuffer();
  
  drawCharge(getTx(), getTy(), getHolding(), getHoldT(), getSliderValue());
  drawFPS(fpsDisplay);
  
  ctx.fillStyle = 'rgba(180,210,255,.15)';
  ctx.font = '8px "Space Mono",monospace';
  ctx.fillText(`${(cam.zoom*100).toFixed(0)}%  SCROLL·ZOOM  RIGHT-DRAG·PAN  F·FIT  SPACE·PAUSE`, 16, H-16);
  
  document.getElementById('cursor').style.left = getTx()+'px';
  document.getElementById('cursor').style.top = getTy()+'px';
}

function init() {
  canvas = document.getElementById('c');
  ctx = canvas.getContext('2d');
  W = canvas.width = window.innerWidth;
  H = canvas.height = window.innerHeight;
  initCamera(W, H, ctx);
  initRendering(W, H, ctx);
  const ui = initUI(W, H, ctx, canvas, () => { bodies.length = 0; loose.length = 0; flashes.length = 0; });
  window.uiGetters = {
    getTx: () => ui.getTx(),
    getTy: () => ui.getTy(),
    getHolding: () => ui.getHolding(),
    getHoldT: () => ui.getHoldT(),
    getSliderValue: () => ui.getSliderValue(),
  };
  window.physSpeed = ui.getPhysSpeed();
  window.paused = ui.getPaused();
  window.togglePause = () => { window.paused = !window.paused; };
  window.updateSpeedBar = () => {};
  window.updateZoomBar = () => {};
  window.addEventListener('resize', resize);
  lastT = performance.now();
  requestAnimationFrame(mainLoop);
}

init();