import { SUN, GRAV_CONST, sunGravMult, SUBSTEPS } from './constants.js';
import { cam, screenToWorld } from './camera.js';
import { PI2, clamp, lerp } from './utils.js';

let _previewCache = null;
const FIXED_NP = 100;
const PREVIEW_RECORD = 20;
const TARGET_ORBITS = 5;

function orbitalSpeed(dist, nP, grav) {
  const g = (grav != null) ? grav : sunGravMult;
  return Math.sqrt(GRAV_CONST * SUN.mass * g / Math.max(nP,1) / Math.max(dist,1));
}

function orbitalPeriod(dist, nP, grav) {
  const v = orbitalSpeed(dist, nP, grav);
  return v > 0 ? (2*Math.PI*dist/v) : 99999;
}

function getSpawnVelocity(x, y, nP, grav) {
  const g = (grav != null) ? grav : sunGravMult;
  const dx = x - SUN.x, dy = y - SUN.y, dist = Math.hypot(dx,dy) || 1;
  const v = orbitalSpeed(dist, nP, g);
  return { vx: -dy/dist * v, vy: dx/dist * v, dist };
}

function computePreviewDamping(periodSub) {
  return Math.pow(0.88, 1/Math.max(periodSub, 1));
}

function predictOrbit(spawnX, spawnY, vx0, vy0, nP, steps, dtPerStep, recordEvery, grav) {
  const pts = [];
  let px = spawnX, py = spawnY, vx = vx0, vy = vy0;
  const g = (grav != null) ? grav : sunGravMult;
  const gm = GRAV_CONST * SUN.mass * g / Math.max(nP,1);
  const burnR2 = SUN.burnRadius * SUN.burnRadius;
  recordEvery = recordEvery || 1;
  const periodSub = orbitalPeriod(Math.hypot(spawnX-SUN.x, spawnY-SUN.y)||1, nP, g) / dtPerStep;
  const vDamp = computePreviewDamping(periodSub);
  for(let i=0; i<steps; i++) {
    const sdx = SUN.x - px, sdy = SUN.y - py;
    const sd2 = sdx*sdx + sdy*sdy;
    if(sd2 < burnR2) break;
    const sd = Math.sqrt(sd2)+0.1;
    const f = gm / (sd2+500);
    vx = (vx + sdx/sd * f * dtPerStep) * vDamp;
    vy = (vy + sdy/sd * f * dtPerStep) * vDamp;
    px += vx * dtPerStep;
    py += vy * dtPerStep;
    if(i % recordEvery === 0) pts.push({x:px, y:py});
  }
  return pts;
}

export function getPreviewPath(wx, wy) {
  if(_previewCache &&
     Math.abs(_previewCache.wx - wx) < 2 &&
     Math.abs(_previewCache.wy - wy) < 2 &&
     _previewCache.mult === sunGravMult) {
    return _previewCache.pts;
  }
  const dist = Math.hypot(wx - SUN.x, wy - SUN.y) || 1;
  const dtPerStep = 1 / SUBSTEPS;
  const periodSub = orbitalPeriod(dist, FIXED_NP, sunGravMult) / dtPerStep;
  const totalSteps = Math.min(Math.ceil(periodSub*(TARGET_ORBITS+2)), 120000);
  const {vx, vy} = getSpawnVelocity(wx, wy, FIXED_NP, sunGravMult);
  const pts = predictOrbit(wx, wy, vx, vy, FIXED_NP, totalSteps, dtPerStep, PREVIEW_RECORD, sunGravMult);
  _previewCache = {wx, wy, pts, mult: sunGravMult};
  return pts;
}

export function drawOrbitPreviewFull(ctx, t, tx, ty, holding, holdT, sliderValue, physSpeed) {
  if(!holding) return;
  const charge = Math.min((performance.now() - holdT)/2000, 1);
  const alpha = clamp(charge*1.6, 0, 0.9);
  if(alpha <= 0) return;
  
  const w = screenToWorld(tx, ty);
  const dx = w.x - SUN.x, dy = w.y - SUN.y;
  const dist = Math.hypot(dx,dy) || 1;
  const pts = getPreviewPath(w.x, w.y);
  if(pts.length < 4) return;
  
  const total = pts.length;
  const lw = 1.8 / cam.zoom;
  
  ctx.save();
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  const SEG = Math.max(2, Math.floor(total/60));
  for(let i=0; i<total-SEG; i+=SEG) {
    const f0 = i/total;
    const f1 = (i+SEG)/total;
    const fc = (f0+f1)/2;
    const r = Math.floor(lerp(160, 255, Math.min(fc*1.8, 1)));
    const g = Math.floor(lerp(220, 120, fc));
    const b = Math.floor(lerp(255, 20, Math.min(fc*1.5, 1)));
    const a = alpha * (1 - fc*0.5) * (f0<0.12 ? f0/0.12 : 1);
    const w2 = lw * (1.4 - fc*0.9);
    ctx.beginPath();
    ctx.moveTo(pts[i].x, pts[i].y);
    for(let j=i+1; j<=i+SEG && j<total; j++) ctx.lineTo(pts[j].x, pts[j].y);
    ctx.strokeStyle = `rgba(${r},${g},${b},${a})`;
    ctx.lineWidth = Math.max(0.3/cam.zoom, w2);
    ctx.stroke();
  }
  const animFrac = (performance.now() * 0.00035) % 1;
  const DOT_COUNT = 7;
  for(let d=0; d<DOT_COUNT; d++) {
    const f = ((d/DOT_COUNT)+animFrac) % 1;
    const idx = Math.floor(f*(total-1));
    const pt = pts[idx];
    const r2 = Math.floor(lerp(160,255,Math.min(f*1.8,1)));
    const g2 = Math.floor(lerp(220,120,f));
    const b2 = Math.floor(lerp(255,20,Math.min(f*1.5,1)));
    const dotR = Math.max(0.8/cam.zoom, (3-f*1.5)/cam.zoom);
    const da = alpha*(1-f*0.4)*0.95;
    ctx.beginPath(); ctx.arc(pt.x,pt.y,dotR,0,PI2);
    ctx.fillStyle = `rgba(${r2},${g2},${b2},${da})`; ctx.fill();
  }
  ctx.restore();
  
  ctx.save();
  ctx.globalAlpha = alpha*0.28;
  ctx.setLineDash([3/cam.zoom, 4/cam.zoom]);
  ctx.beginPath(); ctx.moveTo(SUN.x,SUN.y); ctx.lineTo(w.x,w.y);
  ctx.strokeStyle = 'rgba(255,200,80,1)';
  ctx.lineWidth = 0.6/cam.zoom; ctx.stroke();
  ctx.setLineDash([]);
  ctx.restore();
  
  const dirX = -dy/dist, dirY = dx/dist;
  const alen = Math.min(dist*0.13, 240/cam.zoom);
  const ax = w.x + dirX*alen, ay = w.y + dirY*alen;
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.strokeStyle = 'rgba(160,225,255,1)';
  ctx.fillStyle = 'rgba(160,225,255,1)';
  ctx.lineWidth = lw*0.85;
  ctx.beginPath(); ctx.moveTo(w.x,w.y); ctx.lineTo(ax,ay); ctx.stroke();
  const ha = Math.atan2(dirY, dirX), hl = alen*0.3;
  ctx.beginPath();
  ctx.moveTo(ax,ay);
  ctx.lineTo(ax - Math.cos(ha-0.38)*hl, ay - Math.sin(ha-0.38)*hl);
  ctx.lineTo(ax - Math.cos(ha+0.38)*hl, ay - Math.sin(ha+0.38)*hl);
  ctx.closePath(); ctx.fill();
  ctx.restore();
  
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.beginPath(); ctx.arc(w.x,w.y, 3.5/cam.zoom, 0, PI2);
  ctx.fillStyle = 'rgba(160,225,255,1)'; ctx.fill();
  ctx.restore();
  
  const period_frames = Math.round(orbitalPeriod(dist, FIXED_NP, sunGravMult) / physSpeed);
  const midSX = ((SUN.x - cam.x)*cam.zoom + window.innerWidth/2 + (w.x - cam.x)*cam.zoom + window.innerWidth/2)/2;
  const midSY = ((SUN.y - cam.y)*cam.zoom + window.innerHeight/2 + (w.y - cam.y)*cam.zoom + window.innerHeight/2)/2;
  ctx.font = '8px "Space Mono",monospace';
  ctx.fillStyle = `rgba(180,215,255,${alpha*0.65})`;
  ctx.fillText(`r${Math.round(dist)}  ~${period_frames}f`, midSX+8, midSY-4);
  ctx.restore();
}