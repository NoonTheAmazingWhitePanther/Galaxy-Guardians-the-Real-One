import { GRAV_CONST, SPRING_K, DAMPING, SUBSTEPS, PARTICLE_R, COLLISION_R, sunGravMult, updateCollisionRadius, resetPhysicsParams } from './constants.js';
import { cam, frameBodies, screenToWorld } from './camera.js';
import { bodies, spawnPlanet, setUpdateCountCallback } from './bodies.js';
import { clamp } from './utils.js';

let W, H, ctx;
let tx = 0, ty = 0, holding = false, holdT = 0;
let physSpeed = 1, paused = false;
const SPEED_MAX = 8;

export function initUI(width, height, context, canvasElem, clearCallback) {
  W = width; H = height; ctx = context;
  // Setup sliders and buttons
  const gravSlider = document.getElementById('grav-slider');
  const gravVal = document.getElementById('grav-val');
  const sizeSlider = document.getElementById('size-slider');
  const clearBtn = document.getElementById('clear-btn');
  const configBtn = document.getElementById('config-btn');
  const configMenu = document.getElementById('config-menu');
  const cfgGrav = document.getElementById('cfg-grav');
  const cfgGravVal = document.getElementById('cfg-grav-val');
  const cfgSpring = document.getElementById('cfg-spring');
  const cfgSpringVal = document.getElementById('cfg-spring-val');
  const cfgDamp = document.getElementById('cfg-damp');
  const cfgDampVal = document.getElementById('cfg-damp-val');
  const cfgSubsteps = document.getElementById('cfg-substeps');
  const cfgSubstepsVal = document.getElementById('cfg-substeps-val');
  const cfgCollr = document.getElementById('cfg-collr');
  const cfgCollrVal = document.getElementById('cfg-collr-val');
  const cfgPr = document.getElementById('cfg-pr');
  const cfgPrVal = document.getElementById('cfg-pr-val');
  const cfgReset = document.getElementById('cfg-reset-btn');
  
  // Gravity slider
  gravSlider.addEventListener('input', () => {
    window.sunGravMult = parseFloat(gravSlider.value);
    gravVal.textContent = window.sunGravMult.toFixed(2) + '×';
  });
  // Config menu
  configBtn.addEventListener('click', () => configMenu.classList.toggle('open'));
  // Config values
  cfgGrav.value = GRAV_CONST; cfgGravVal.textContent = GRAV_CONST;
  cfgGrav.addEventListener('input', () => { window.GRAV_CONST = parseFloat(cfgGrav.value); cfgGravVal.textContent = window.GRAV_CONST; });
  cfgSpring.value = SPRING_K; cfgSpringVal.textContent = SPRING_K.toFixed(2);
  cfgSpring.addEventListener('input', () => { window.SPRING_K = parseFloat(cfgSpring.value); cfgSpringVal.textContent = window.SPRING_K.toFixed(2); });
  cfgDamp.value = DAMPING; cfgDampVal.textContent = DAMPING.toFixed(3);
  cfgDamp.addEventListener('input', () => { window.DAMPING = parseFloat(cfgDamp.value); cfgDampVal.textContent = window.DAMPING.toFixed(3); });
  cfgSubsteps.value = SUBSTEPS; cfgSubstepsVal.textContent = SUBSTEPS;
  cfgSubsteps.addEventListener('input', () => { window.SUBSTEPS = parseInt(cfgSubsteps.value); cfgSubstepsVal.textContent = window.SUBSTEPS; });
  cfgPr.value = PARTICLE_R; cfgPrVal.textContent = PARTICLE_R.toFixed(1);
  cfgPr.addEventListener('input', () => { window.PARTICLE_R = parseFloat(cfgPr.value); updateCollisionRadius(); cfgPrVal.textContent = window.PARTICLE_R.toFixed(1); });
  cfgCollr.value = COLLISION_R; cfgCollrVal.textContent = COLLISION_R.toFixed(2);
  cfgCollr.addEventListener('input', () => { window.COLLISION_R = parseFloat(cfgCollr.value); cfgCollrVal.textContent = window.COLLISION_R.toFixed(2); });
  cfgReset.addEventListener('click', () => { resetPhysicsParams(); cfgGrav.value = GRAV_CONST; cfgGravVal.textContent = GRAV_CONST; cfgSpring.value = SPRING_K; cfgSpringVal.textContent = SPRING_K.toFixed(2); cfgDamp.value = DAMPING; cfgDampVal.textContent = DAMPING.toFixed(3); cfgSubsteps.value = SUBSTEPS; cfgSubstepsVal.textContent = SUBSTEPS; cfgPr.value = PARTICLE_R; cfgPrVal.textContent = PARTICLE_R.toFixed(1); cfgCollr.value = COLLISION_R; cfgCollrVal.textContent = COLLISION_R.toFixed(2); });
  
  clearBtn.addEventListener('click', clearCallback);
  
  // Speed bar
  const spFast = document.getElementById('sp-fast');
  const spSlow = document.getElementById('sp-slow');
  const spTrack = document.getElementById('sp-track');
  const spFill = document.getElementById('sp-fill');
  const spThumb = document.getElementById('sp-thumb');
  const spLabel = document.getElementById('sp-label');
  const spPause = document.getElementById('sp-pause');
  
  function updateSpeedBar() {
    const frac = physSpeed/SPEED_MAX;
    spFill.style.height = (frac*100)+'%';
    spThumb.style.top = ((1-frac)*100)+'%';
    spLabel.textContent = physSpeed===0?'0×':physSpeed===1?'1×':physSpeed.toFixed(1)+'×';
    spPause.textContent = paused?'▶':'▐▐';
    spPause.className = paused?'paused':'';
  }
  function setSpeed(v) { physSpeed = clamp(v,0,SPEED_MAX); if(physSpeed>0 && paused) paused=false; updateSpeedBar(); }
  window.togglePause = () => { paused = !paused; if(!paused && physSpeed===0) physSpeed=1; updateSpeedBar(); };
  function spTrackPos(clientY) {
    const rect = spTrack.getBoundingClientRect();
    setSpeed( clamp(1-(clientY-rect.top)/rect.height, 0, 1) * SPEED_MAX );
  }
  spFast.addEventListener('pointerdown', e => { e.preventDefault(); setSpeed(physSpeed+0.5); });
  spSlow.addEventListener('pointerdown', e => { e.preventDefault(); setSpeed(physSpeed-0.5); });
  spPause.addEventListener('pointerdown', e => { e.preventDefault(); window.togglePause(); });
  let spDrag = false;
  spTrack.addEventListener('pointerdown', e => { spDrag=true; spTrackPos(e.clientY); e.preventDefault(); });
  window.addEventListener('pointermove', e => { if(spDrag) spTrackPos(e.clientY); });
  window.addEventListener('pointerup', () => { spDrag=false; });
  
  // Zoom bar
  const zmIn = document.getElementById('zm-in');
  const zmOut = document.getElementById('zm-out');
  const zmFit = document.getElementById('zm-fit');
  const zmTrack = document.getElementById('zm-track');
  const zmFill = document.getElementById('zm-fill');
  const zmThumb = document.getElementById('zm-thumb');
  const zmLabel = document.getElementById('zm-label');
  function updateZoomBar() {
    const logMin = Math.log(cam.minZoom), logMax = Math.log(cam.maxZoom);
    const frac = clamp((Math.log(cam.targetZoom)-logMin)/(logMax-logMin), 0, 1);
    zmFill.style.height = (frac*100)+'%';
    zmThumb.style.top = ((1-frac)*100)+'%';
    zmLabel.textContent = (cam.targetZoom*100).toFixed(0)+'%';
  }
  function zmTrackPos(clientY) {
    const rect = zmTrack.getBoundingClientRect();
    const frac = clamp(1-(clientY-rect.top)/rect.height, 0, 1);
    const logMin=Math.log(cam.minZoom), logMax=Math.log(cam.maxZoom);
    cam.targetZoom = Math.exp(logMin + frac*(logMax-logMin));
  }
  zmIn.addEventListener('pointerdown', e => { e.preventDefault(); cam.targetZoom = clamp(cam.targetZoom*1.3, cam.minZoom, cam.maxZoom); });
  zmOut.addEventListener('pointerdown', e => { e.preventDefault(); cam.targetZoom = clamp(cam.targetZoom/1.3, cam.minZoom, cam.maxZoom); });
  zmFit.addEventListener('pointerdown', e => { e.preventDefault(); frameBodies(bodies, window.SUN); });
  let zmDrag = false;
  zmTrack.addEventListener('pointerdown', e => { zmDrag=true; zmTrackPos(e.clientY); e.preventDefault(); });
  window.addEventListener('pointermove', e => { if(zmDrag) zmTrackPos(e.clientY); });
  window.addEventListener('pointerup', () => { zmDrag=false; });
  
  // Mouse/Touch spawning
  canvasElem.addEventListener('mousemove', e => { tx = e.clientX; ty = e.clientY; });
  canvasElem.addEventListener('mousedown', e => {
    if(e.button !== 0 || e.target.closest('#ui') || e.target.closest('#speed-bar') || e.target.closest('#zoom-bar') || e.target.closest('#config-menu')) return;
    holding = true; holdT = performance.now(); document.getElementById('cursor').classList.add('holding');
  });
  window.addEventListener('mouseup', e => {
    if(!holding) return;
    holding = false; document.getElementById('cursor').classList.remove('holding');
    const charge = Math.min((performance.now()-holdT)/2000, 1);
    const size = parseFloat(sizeSlider.value) * (1+charge*4);
    const w = screenToWorld(tx, ty);
    spawnPlanet(w.x, w.y, size, window.GRAV_CONST, window.SUN, window.sunGravMult);
  });
  // Touch events
  canvasElem.addEventListener('touchstart', e => {
    if(e.touches.length === 1 && !holding) {
      const t = e.touches[0]; tx = t.clientX; ty = t.clientY;
      holding = true; holdT = performance.now(); document.getElementById('cursor').classList.add('holding');
      e.preventDefault();
    }
  });
  canvasElem.addEventListener('touchmove', e => { if(e.touches.length === 1) { tx = e.touches[0].clientX; ty = e.touches[0].clientY; } });
  canvasElem.addEventListener('touchend', e => {
    if(holding) {
      holding = false; document.getElementById('cursor').classList.remove('holding');
      const charge = Math.min((performance.now()-holdT)/2000, 1);
      const size = parseFloat(sizeSlider.value) * (1+charge*4);
      const w = screenToWorld(tx, ty);
      spawnPlanet(w.x, w.y, size, window.GRAV_CONST, window.SUN, window.sunGravMult);
    }
  });
  
  // Keyboard
  window.addEventListener('keydown', e => {
    if(e.key === '=' || e.key === '+') cam.targetZoom = clamp(cam.targetZoom*1.2, cam.minZoom, cam.maxZoom);
    if(e.key === '-') cam.targetZoom = clamp(cam.targetZoom/1.2, cam.minZoom, cam.maxZoom);
    if(e.key === '0' || e.key === 'r') { cam.targetZoom = 1; cam.x = 0; cam.y = 0; }
    if(e.key === 'f') frameBodies(bodies, window.SUN);
    if(e.key === ' ' || e.key === 'p') { e.preventDefault(); window.togglePause(); }
    if(e.key === ']') setSpeed(physSpeed+0.5);
    if(e.key === '[') setSpeed(physSpeed-0.5);
  });
  
  // Expose globals for other modules
  window.physSpeed = physSpeed;
  window.updateSpeedBar = updateSpeedBar;
  window.updateZoomBar = updateZoomBar;
  
  setUpdateCountCallback(() => {
    let n = 0; for(const b of bodies) if(!b.dead) n++;
    document.getElementById('pcount').textContent = n===0 ? '—' : `${n} WORLD${n!==1?'S':''}`;
  });
  
  return { getPhysSpeed: () => physSpeed, getPaused: () => paused, getTx: () => tx, getTy: () => ty, getHolding: () => holding, getHoldT: () => holdT, getSliderValue: () => sizeSlider.value };
}