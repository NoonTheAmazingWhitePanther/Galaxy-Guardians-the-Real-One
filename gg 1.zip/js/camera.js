import { clamp } from './utils.js';

let W, H, ctx;

export const cam = {
  x: 0, y: 0,
  zoom: 0.08,
  targetZoom: 0.08,
  minZoom: 0.01,
  maxZoom: 4,
};

export function initCamera(width, height, context) {
  W = width;
  H = height;
  ctx = context;
}

export function screenToWorld(sx, sy) {
  return {
    x: cam.x + (sx - W/2) / cam.zoom,
    y: cam.y + (sy - H/2) / cam.zoom,
  };
}

export function applyCam() {
  ctx.translate(W/2, H/2);
  ctx.scale(cam.zoom, cam.zoom);
  ctx.translate(-cam.x, -cam.y);
}

export function tickCam() {
  cam.zoom += (cam.targetZoom - cam.zoom) * 0.1;
}

export function frameBodies(bodies, SUN) {
  const pad = 300;
  let minX = -SUN.radius*6, maxX = SUN.radius*6, minY = -SUN.radius*6, maxY = SUN.radius*6;
  for(const b of bodies) {
    minX = Math.min(minX, b.cx - b.radius);
    maxX = Math.max(maxX, b.cx + b.radius);
    minY = Math.min(minY, b.cy - b.radius);
    maxY = Math.max(maxY, b.cy + b.radius);
  }
  cam.x = (minX+maxX)/2;
  cam.y = (minY+maxY)/2;
  cam.targetZoom = clamp(Math.min(W/(maxX-minX+pad*2), H/(maxY-minY+pad*2)), cam.minZoom, cam.maxZoom);
}