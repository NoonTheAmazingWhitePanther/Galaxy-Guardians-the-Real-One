import { SUN, PALS, TRAIL_STEPS, TRAIL_ALPHAS, PARTICLE_R } from './constants.js';
import { bodies, loose, flashes } from './bodies.js';
import { asteroids, drawAsteroids } from './asteroids.js';
import { cam, applyCam } from './camera.js';
import { convexHull, PI2, clamp, lerp, rnd, rndR } from './utils.js';

let W, H, ctx;
let stars = [];
let trailBufs = [];
let trailHead = 0;

export function initRendering(width, height, context) {
  W = width; H = height; ctx = context;
  initStars();
  initTrailBuffers();
}

function initStars() {
  stars = Array.from({length:180}, () => ({
    x: rnd()*W, y: rnd()*H, r: rnd()*1.2+0.2,
    bri: rnd()*0.5+0.5, ts: rnd()*0.012+0.003, to: rnd()*PI2, hue: 200+rnd()*60,
  }));
}

export function drawStars(t) {
  for(const s of stars) {
    const a = s.bri * (0.55 + 0.45*Math.sin(t*s.ts + s.to));
    ctx.beginPath(); ctx.arc(s.x, s.y, s.r, 0, PI2);
    ctx.fillStyle = `hsla(${s.hue},75%,95%,${a})`;
    ctx.shadowBlur = 3; ctx.shadowColor = `hsla(${s.hue},100%,95%,.3)`;
    ctx.fill(); ctx.shadowBlur = 0;
  }
}

export function drawNebula(t) {
  const blobs = [
    [W*0.2,  H*0.3,  Math.max(W,H)*0.7,  8,  6, 38, 0.04],
    [W*0.78, H*0.7,  Math.max(W,H)*0.6,  28, 4, 18, 0.035],
    [W*0.5,  H*0.15, Math.max(W,H)*0.5,  4, 12, 40, 0.03],
    [W*0.85, H*0.4,  Math.max(W,H)*0.45, 12, 3, 30, 0.025],
    [W*0.1,  H*0.75, Math.max(W,H)*0.5,  6, 20, 12, 0.02],
  ];
  for(const [bx,by,br,r,g,b,a] of blobs) {
    const px = bx + Math.sin(t*0.00007)*30, py = by + Math.cos(t*0.00009)*20;
    const grd = ctx.createRadialGradient(px,py,0,px,py,br);
    grd.addColorStop(0, `rgba(${r},${g},${b},${a})`);
    grd.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = grd; ctx.fillRect(0,0,W,H);
  }
}

export function drawSun(t, SUN) {
  const {x,y,radius} = SUN;
  SUN.coronaTime += 0.008;
  const ct = SUN.coronaTime;
  
  for(const [r,a,sp] of [[radius*5.5,0.015,0.0011],[radius*3.8,0.03,0.0017],[radius*2.5,0.055,0.002],[radius*1.7,0.09,0.0025]]) {
    const pulse = 1 + 0.06*Math.sin(ct*sp*1000);
    const gr = ctx.createRadialGradient(x,y,radius*0.6, x,y, r*pulse);
    gr.addColorStop(0, `rgba(255,200,60,${a})`);
    gr.addColorStop(0.4, `rgba(255,120,20,${a*0.4})`);
    gr.addColorStop(1, `rgba(255,60,0,0)`);
    ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(x,y,r*pulse,0,PI2); ctx.fill();
  }
  ctx.save();
  for(let i=0;i<12;i++) {
    const angle = PI2/12*i + Math.sin(ct*0.7+i)*0.15;
    const flicker = Math.sin(ct*1.3+i*2.1)*0.5+0.5;
    const len = radius*(0.35 + flicker*0.55);
    const tipX = x + Math.cos(angle)*(radius+len), tipY = y + Math.sin(angle)*(radius+len);
    const lx = x + Math.cos(angle-Math.PI/2)*radius*0.12, ly = y + Math.sin(angle-Math.PI/2)*radius*0.12;
    const rx = x + Math.cos(angle+Math.PI/2)*radius*0.12, ry = y + Math.sin(angle+Math.PI/2)*radius*0.12;
    const fg = ctx.createLinearGradient(x,y,tipX,tipY);
    fg.addColorStop(0, `rgba(255,230,100,${0.25*flicker})`);
    fg.addColorStop(0.5, `rgba(255,140,30,${0.15*flicker})`);
    fg.addColorStop(1, `rgba(255,60,0,0)`);
    ctx.beginPath(); ctx.moveTo(lx,ly);
    ctx.quadraticCurveTo(tipX+Math.cos(angle)*radius*0.1, tipY+Math.sin(angle)*radius*0.1, rx,ry);
    ctx.quadraticCurveTo(x+Math.cos(angle)*radius*0.7, y+Math.sin(angle)*radius*0.7, lx,ly);
    ctx.fillStyle = fg; ctx.fill();
  }
  ctx.restore();
  ctx.save();
  ctx.beginPath(); ctx.arc(x,y,radius,0,PI2); ctx.clip();
  const bg = ctx.createRadialGradient(x-radius*0.2, y-radius*0.2,0, x,y,radius);
  bg.addColorStop(0,'#fffde0'); bg.addColorStop(0.15,'#ffe066'); bg.addColorStop(0.45,'#ff9900');
  bg.addColorStop(0.8,'#ff4400'); bg.addColorStop(1,'#cc1100');
  ctx.fillStyle = bg; ctx.fillRect(x-radius,y-radius,radius*2,radius*2);
  for(let i=0;i<28;i++) {
    const ga = PI2/28*i + ct*0.03*(i%2?1:-1);
    const gd = (0.35+0.5*(i%7)/7)*radius;
    const gx = x+Math.cos(ga)*gd, gy = y+Math.sin(ga)*gd, gr2 = radius*(0.06+0.08*((i*7)%5)/5);
    const granG = ctx.createRadialGradient(gx,gy,0,gx,gy,gr2);
    granG.addColorStop(0, `rgba(255,240,150,${(0.5+0.5*Math.sin(ct*2.1+i*1.3))*0.18})`);
    granG.addColorStop(1, 'rgba(255,100,0,0)');
    ctx.fillStyle = granG; ctx.beginPath(); ctx.arc(gx,gy,gr2,0,PI2); ctx.fill();
  }
  for(const [a,d,r,fl] of [[0.8,0.42,0.09,1.1],[2.3,0.55,0.06,0.9],[4.1,0.35,0.07,1.2],[5.5,0.5,0.05,0.8]]) {
    const sa = a + ct*0.04*(fl-0.9);
    const sx = x+Math.cos(sa)*d*radius, sy = y+Math.sin(sa)*d*radius, sr = r*radius;
    const sg = ctx.createRadialGradient(sx,sy,0,sx,sy,sr);
    sg.addColorStop(0, 'rgba(30,10,0,0.65)');
    sg.addColorStop(0.6, 'rgba(80,20,0,0.35)');
    sg.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = sg; ctx.beginPath(); ctx.arc(sx,sy,sr,0,PI2); ctx.fill();
  }
  const hl = ctx.createRadialGradient(x-radius*0.38, y-radius*0.42,0, x-radius*0.38, y-radius*0.42, radius*0.7);
  hl.addColorStop(0, 'rgba(255,255,255,0.22)'); hl.addColorStop(1, 'rgba(255,255,255,0)');
  ctx.fillStyle = hl; ctx.fillRect(x-radius,y-radius,radius*2,radius*2);
  ctx.restore();
  const rim = ctx.createRadialGradient(x,y,radius*0.88, x,y, radius*1.22);
  rim.addColorStop(0, 'rgba(0,0,0,0)'); rim.addColorStop(0.4, 'rgba(255,160,20,0.12)'); rim.addColorStop(1, 'rgba(255,40,0,0)');
  ctx.fillStyle = rim; ctx.beginPath(); ctx.arc(x,y,radius*1.22,0,PI2); ctx.fill();
  ctx.save(); ctx.globalAlpha = 0.018;
  for(let i=0;i<6;i++) {
    const sa = ct*0.05 + PI2/6*i;
    const ex = x+Math.cos(sa)*radius*18, ey = y+Math.sin(sa)*radius*18;
    const lx2 = x+Math.cos(sa-Math.PI/2)*radius*0.8, ly2 = y+Math.sin(sa-Math.PI/2)*radius*0.8;
    const rx2 = x+Math.cos(sa+Math.PI/2)*radius*0.8, ry2 = y+Math.sin(sa+Math.PI/2)*radius*0.8;
    const sg = ctx.createLinearGradient(x,y,ex,ey);
    sg.addColorStop(0, 'rgba(255,220,80,1)'); sg.addColorStop(1, 'rgba(255,120,0,0)');
    ctx.beginPath(); ctx.moveTo(lx2,ly2); ctx.lineTo(ex,ey); ctx.lineTo(rx2,ry2); ctx.closePath();
    ctx.fillStyle = sg; ctx.fill();
  }
  ctx.restore();
}

export function drawLoose() {
  const hot = [], warm = [], cool = new Map(), ring = new Map();
  for(const p of loose) {
    const life = Math.min(p.life,1);
    const r = Math.max(0.01, PARTICLE_R*(p.isRing?1.4:1)*life);
    const a = life;
    if(p.isRing) {
      const key = p.pal.gc;
      if(!ring.has(key)) ring.set(key,[]);
      ring.get(key).push([p.x,p.y,r,a*0.85]);
    } else if(p.heat > 0.6) hot.push([p.x,p.y,r,a*0.9]);
    else if(p.heat > 0.3) warm.push([p.x,p.y,r,a*0.85]);
    else {
      const key = p.pal.gc;
      if(!cool.has(key)) cool.set(key,[]);
      cool.get(key).push([p.x,p.y,r,a*0.8]);
    }
  }
  const drawBatch = (style, arr) => {
    if(!arr.length) return;
    ctx.fillStyle = style;
    for(const [x,y,r,a] of arr) { ctx.globalAlpha = a; ctx.beginPath(); ctx.arc(x,y,r,0,PI2); ctx.fill(); }
  };
  for(const [gc, pts] of ring) {
    ctx.shadowBlur = 3; ctx.shadowColor = `rgba(${gc},.6)`;
    drawBatch(`rgba(${gc},1)`, pts);
    ctx.shadowBlur = 0;
  }
  drawBatch('rgba(255,220,80,1)', hot);
  drawBatch('rgba(255,100,30,1)', warm);
  for(const [gc, pts] of cool) drawBatch(`rgba(${gc},1)`, pts);
  ctx.globalAlpha = 1;
}

export function drawBody(body) {
  const {particles:ps, springs:ss, pal} = body;
  const alive = [];
  for(const p of ps) if(!p.dead) alive.push(p);
  if(alive.length < 3) return;
  const hull = convexHull(alive);
  if(hull.length > 2) {
    ctx.save();
    ctx.beginPath(); ctx.moveTo(hull[0].x, hull[0].y);
    for(let i=1;i<hull.length;i++) ctx.lineTo(hull[i].x, hull[i].y);
    ctx.closePath();
    const gr = ctx.createRadialGradient(body.cx, body.cy, 0, body.cx, body.cy, body.radius);
    gr.addColorStop(0, pal.hi+'dd'); gr.addColorStop(0.35, pal.mid+'cc');
    gr.addColorStop(0.75, pal.lo+'bb'); gr.addColorStop(1, pal.lo+'44');
    ctx.fillStyle = gr; ctx.fill();
    ctx.strokeStyle = `rgba(${pal.gc},.35)`;
    ctx.lineWidth = 1.5/cam.zoom; ctx.stroke();
    ctx.restore();
  }
  ctx.save(); ctx.globalAlpha = 0.08; ctx.strokeStyle = `rgba(${pal.gc},.9)`;
  ctx.lineWidth = 0.8/cam.zoom; ctx.beginPath();
  for(const sp of ss) {
    if(sp.broken) continue;
    const pa = ps[sp.a], pb = ps[sp.b];
    if(pa.dead || pb.dead) continue;
    if(Math.hypot(pb.x-pa.x, pb.y-pa.y)/sp.restLen < 1.1) continue;
    ctx.moveTo(pa.x, pa.y); ctx.lineTo(pb.x, pb.y);
  }
  ctx.stroke(); ctx.restore();
  ctx.fillStyle = `rgba(${pal.gc},.75)`;
  ctx.beginPath();
  for(const p of alive) {
    if(p.heat > 0.05) continue;
    const r = p.isCore ? PARTICLE_R*1.3 : PARTICLE_R;
    ctx.moveTo(p.x+r, p.y); ctx.arc(p.x,p.y,r,0,PI2);
    p.heat = Math.max(0, p.heat-0.012);
  }
  ctx.fill();
  for(const p of alive) {
    if(p.heat <= 0.05) continue;
    const r = p.isCore ? PARTICLE_R*1.3 : PARTICLE_R;
    ctx.fillStyle = `rgba(255,${Math.floor(lerp(60,220,p.heat))},30,${p.heat*0.9})`;
    ctx.beginPath(); ctx.arc(p.x,p.y,r,0,PI2); ctx.fill();
    p.heat = Math.max(0, p.heat-0.012);
  }
  const atm = ctx.createRadialGradient(body.cx, body.cy, body.radius*0.7, body.cx, body.cy, body.radius*1.8);
  atm.addColorStop(0, `rgba(${pal.gc},.08)`); atm.addColorStop(1, `rgba(${pal.gc},0)`);
  ctx.fillStyle = atm; ctx.beginPath(); ctx.arc(body.cx, body.cy, body.radius*1.8, 0, PI2); ctx.fill();
}

export function drawFlashes() {
  for(let i=flashes.length-1; i>=0; i--) {
    const f = flashes[i];
    f.life -= 0.042;
    if(f.life <= 0) { flashes.splice(i,1); continue; }
    const r = Math.max(0.1, f.r);
    const a = clamp(f.life, 0, 1);
    if(f.kind === 'white') {
      const gr = ctx.createRadialGradient(f.x,f.y,0, f.x,f.y, r);
      gr.addColorStop(0, `rgba(255,255,255,${a*0.30})`);
      gr.addColorStop(0.5, `rgba(255,250,240,${a*0.16})`);
      gr.addColorStop(0.85, `rgba(255,240,200,${a*0.06})`);
      gr.addColorStop(1, `rgba(255,255,255,0)`);
      ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(f.x,f.y,r,0,PI2); ctx.fill();
      ctx.beginPath(); ctx.arc(f.x,f.y,r,0,PI2);
      ctx.strokeStyle = `rgba(255,255,255,${a*0.22})`;
      ctx.lineWidth = Math.max(0.3, r*0.04/cam.zoom); ctx.stroke();
    } else if(f.kind === 'ring') {
      ctx.beginPath(); ctx.arc(f.x,f.y,r,0,PI2);
      ctx.strokeStyle = `rgba(${f.gc},${a*0.22})`;
      ctx.lineWidth = Math.max(0.3, (f.maxR*0.025)/cam.zoom)*a;
      ctx.stroke();
      const gr = ctx.createRadialGradient(f.x,f.y, Math.max(0,r*0.75), f.x,f.y, r*1.35);
      gr.addColorStop(0, `rgba(${f.gc},${a*0.08})`);
      gr.addColorStop(1, `rgba(${f.gc},0)`);
      ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(f.x,f.y,r*1.35,0,PI2); ctx.fill();
    } else if(f.kind === 'fill') {
      const gr = ctx.createRadialGradient(f.x,f.y,0, f.x,f.y, r);
      gr.addColorStop(0, `rgba(255,240,200,${a*0.13})`);
      gr.addColorStop(0.4, `rgba(${f.gc},${a*0.09})`);
      gr.addColorStop(0.8, `rgba(${f.gc},${a*0.03})`);
      gr.addColorStop(1, `rgba(${f.gc},0)`);
      ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(f.x,f.y,r,0,PI2); ctx.fill();
    } else if(f.kind === 'core') {
      const gr = ctx.createRadialGradient(f.x,f.y,0, f.x,f.y, r);
      gr.addColorStop(0, `rgba(255,255,255,${a*0.40})`);
      gr.addColorStop(0.35, `rgba(255,230,150,${a*0.20})`);
      gr.addColorStop(0.7, `rgba(${f.gc},${a*0.08})`);
      gr.addColorStop(1, `rgba(${f.gc},0)`);
      ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(f.x,f.y,r,0,PI2); ctx.fill();
    }
    f.r += (f.maxR - f.r) * f.speed;
  }
}

export function drawCharge(tx, ty, holding, holdT, sliderValue) {
  if(!holding) return;
  const charge = Math.min((performance.now() - holdT)/2000, 1);
  const r = clamp(parseFloat(sliderValue)*(1+charge*4)*8, 16, 110) * charge;
  ctx.beginPath(); ctx.arc(tx, ty, r, 0, PI2);
  ctx.strokeStyle = `rgba(255,190,50,${0.15+charge*0.3})`; ctx.lineWidth = 1; ctx.setLineDash([4,4]); ctx.stroke(); ctx.setLineDash([]);
  ctx.beginPath(); ctx.arc(tx, ty, 14, -Math.PI/2, -Math.PI/2 + PI2*charge);
  ctx.strokeStyle = `rgba(255,190,50,${0.5+charge*0.4})`; ctx.lineWidth = 2.5; ctx.stroke();
  ctx.beginPath(); ctx.arc(tx, ty, 3, 0, PI2); ctx.fillStyle = `rgba(255,210,80,${0.7+charge*0.3})`; ctx.fill();
}

export function initTrailBuffers() {
  trailBufs = Array.from({length: TRAIL_STEPS}, () => {
    const c = document.createElement('canvas');
    c.width = W; c.height = H;
    return { canvas: c, ctx: c.getContext('2d'), camX:0, camY:0, camZoom:1, used:false };
  });
  trailHead = 0;
}

export function resizeTrailBuffers() {
  for(const b of trailBufs) { b.canvas.width = W; b.canvas.height = H; b.used = false; }
}

export function renderPlanetsToBuffer() {
  const buf = trailBufs[trailHead];
  const ox = buf.ctx;
  ox.clearRect(0,0,W,H);
  ox.save();
  ox.translate(W/2, H/2);
  ox.scale(cam.zoom, cam.zoom);
  ox.translate(-cam.x, -cam.y);
  for(const b of bodies) {
    const {particles:ps, pal} = b;
    const alive = [];
    for(const p of ps) if(!p.dead) alive.push(p);
    if(alive.length < 3) continue;
    const hull = convexHull(alive);
    if(hull.length < 3) continue;
    ox.save();
    ox.beginPath(); ox.moveTo(hull[0].x, hull[0].y);
    for(let i=1;i<hull.length;i++) ox.lineTo(hull[i].x, hull[i].y);
    ox.closePath();
    const gr = ox.createRadialGradient(b.cx,b.cy,0, b.cx,b.cy, b.radius);
    gr.addColorStop(0, pal.hi+'ff'); gr.addColorStop(0.35, pal.mid+'ee');
    gr.addColorStop(0.75, pal.lo+'cc'); gr.addColorStop(1, pal.lo+'44');
    ox.fillStyle = gr; ox.fill();
    ox.strokeStyle = `rgba(${pal.gc},.4)`;
    ox.lineWidth = 1.5/cam.zoom; ox.stroke();
    ox.restore();
    ox.save(); ox.globalAlpha = 0.07;
    ox.strokeStyle = `rgba(${pal.gc},.9)`;
    ox.lineWidth = 0.8/cam.zoom; ox.beginPath();
    for(const sp of b.springs) {
      if(sp.broken) continue;
      const pa = ps[sp.a], pb = ps[sp.b];
      if(pa.dead || pb.dead) continue;
      if(Math.hypot(pb.x-pa.x, pb.y-pa.y)/sp.restLen < 1.1) continue;
      ox.moveTo(pa.x, pa.y); ox.lineTo(pb.x, pb.y);
    }
    ox.stroke(); ox.restore();
    ox.fillStyle = `rgba(${pal.gc},.75)`;
    ox.beginPath();
    for(const p of alive) {
      if(p.heat > 0.05) continue;
      const r = p.isCore ? PARTICLE_R*1.3 : PARTICLE_R;
      ox.moveTo(p.x+r, p.y); ox.arc(p.x,p.y,r,0,PI2);
    }
    ox.fill();
    for(const p of alive) {
      if(p.heat <= 0.05) continue;
      const r = p.isCore ? PARTICLE_R*1.3 : PARTICLE_R;
      ox.fillStyle = `rgba(255,${Math.floor(lerp(60,220,p.heat))},30,${p.heat*0.9})`;
      ox.beginPath(); ox.arc(p.x,p.y,r,0,PI2); ox.fill();
    }
    const atm = ox.createRadialGradient(b.cx,b.cy, b.radius*0.7, b.cx,b.cy, b.radius*1.8);
    atm.addColorStop(0, `rgba(${pal.gc},.07)`); atm.addColorStop(1, `rgba(${pal.gc},0)`);
    ox.fillStyle = atm; ox.beginPath(); ox.arc(b.cx,b.cy, b.radius*1.8, 0, PI2); ox.fill();
  }
  ox.restore();
  buf.camX = cam.x; buf.camY = cam.y; buf.camZoom = cam.zoom; buf.used = true;
}

export function drawTrail() {
  for(let age = TRAIL_STEPS-1; age >= 0; age--) {
    const idx = ((trailHead - age - 1) + TRAIL_STEPS*2) % TRAIL_STEPS;
    const buf = trailBufs[idx];
    if(!buf.used) continue;
    const alpha = TRAIL_ALPHAS[age];
    if(alpha < 0.005) continue;
    const scaleRatio = cam.zoom / buf.camZoom;
    const offX = (buf.camX - cam.x) * cam.zoom;
    const offY = (buf.camY - cam.y) * cam.zoom;
    ctx.save();
    ctx.globalAlpha = alpha;
    ctx.globalCompositeOperation = age === 0 ? 'source-over' : 'lighter';
    ctx.translate(W/2 + offX, H/2 + offY);
    ctx.scale(scaleRatio, scaleRatio);
    ctx.translate(-W/2, -H/2);
    ctx.drawImage(buf.canvas, 0, 0);
    ctx.restore();
  }
  ctx.globalCompositeOperation = 'source-over';
}

export function advanceTrailBuffer() {
  trailHead = (trailHead + 1) % TRAIL_STEPS;
}

export function drawFPS(fpsDisplay) {
  ctx.save();
  ctx.font = '10px "Space Mono",monospace';
  ctx.fillStyle = 'rgba(100,255,160,0.55)';
  ctx.fillText(`${fpsDisplay} FPS`, 16, 20);
  ctx.restore();
}