export const PI2 = Math.PI * 2;
export const rnd  = Math.random.bind(Math);
export const rndR = (a,b) => a + (b-a)*rnd();
export const clamp = (v, a, b) => v < a ? a : v > b ? b : v;
export const lerp  = (a, b, t) => a + (b-a)*t;

export function makeRockShape(r) {
  const n = Math.floor(rndR(5,9));
  return Array.from({length:n}, (_,i) => {
    const baseA = (PI2/n)*i + (rnd()-0.5)*(PI2/n)*0.55;
    const rv = r * (0.55 + rnd()*0.55);
    return [Math.cos(baseA)*rv, Math.sin(baseA)*rv];
  });
}

export function convexHull(pts) {
  if(pts.length < 3) return pts;
  let lo = pts[0];
  for(const p of pts) if(p.y > lo.y || (p.y === lo.y && p.x < lo.x)) lo = p;
  const hull = [lo];
  let cur = lo;
  while(true) {
    let next = pts[0];
    for(const p of pts) {
      if(p === cur) continue;
      const cross = (next.x - cur.x)*(p.y - cur.y) - (next.y - cur.y)*(p.x - cur.x);
      if(cross < 0 || (cross === 0 && Math.hypot(p.x-cur.x, p.y-cur.y) > Math.hypot(next.x-cur.x, next.y-cur.y))) next = p;
    }
    if(next === lo) break;
    hull.push(next);
    cur = next;
    if(hull.length > pts.length) break;
  }
  return hull;
}